# Spain Historical Fixtures Extraction Pack v0.2

This pack contains the outputs of a five-stage extraction run for the 82 app historical Spanish fixtures database. It is structured for the app journey: click a team, select a season, view that team's fixtures, and mark one as attended.

## Files

- `official_source_map.csv` — every planned official source row by season, competition and jornada.
- `fixtures_results_seed_official_sample.csv` — seed fixture rows transcribed from official LaLiga 2021/22 Jornada 1 pages.
- `team_fixture_index_seed_official_sample.csv` — two team-facing rows per seed fixture.
- `team_aliases_seed.csv` — source-name to team-id mapping for seed teams.
- `source_gap_register.csv` — known gaps and how to close them.
- `extraction_stage_status.csv` — status of the five stages.
- `validation_report.md` — run summary and counts.
- `spain_fixtures_extraction_v0_2.sqlite` — SQLite version with a `vw_team_season_fixtures` view.
- `official_extraction_runner.py` — runnable ETL skeleton for a live HTTP-enabled environment.

## Core app query

```sql
SELECT *
FROM vw_team_season_fixtures
WHERE team_id = 'FC_BARCELONA'
AND season_id = '2021-22'
ORDER BY fixture_date;
```

## Status

The structure and seed extraction are complete. Full bulk population requires running the ETL script against official LaLiga and RFEF sources in an environment that can make live HTTP requests to those sites.
