# Spain Fixture Extraction Run v0.2

Run timestamp: 2026-05-25T07:36:30Z

## Scope
Seasons: 2021-22 to 2025-26 inclusive.
Competitions: Primera División / LALIGA EA SPORTS, Segunda División / LALIGA HYPERMOTION, Primera Federación Group 1, Primera Federación Group 2.

## What was completed in this run
1. Built the official source map for all LaLiga pages by season, competition and jornada.
2. Added RFEF source discovery rows for Primera Federación Group 1 and Group 2.
3. Extracted and normalised an official seed sample from LaLiga 2021-22 Jornada 1 for Primera and Segunda.
4. Generated the app-facing team fixture index, two rows per fixture.
5. Built validation outputs and a SQLite database.

## Limitation
The full automated corpus was not fetched in this ChatGPT environment because the official sites do not expose a single bulk historical CSV/API through the web tool, and the local execution environment cannot make live HTTP requests to crawl hundreds of pages. The pack therefore contains a verified extraction structure plus an official source sample, not the completed c.8,000-fixture corpus.

## Counts in this pack
- Seed fixtures: 21
- Team fixture index rows: 42
- Unique source team names in seed: 42
- Source map rows: 780

## Next operational step
Run `official_extraction_runner.py` in an environment with HTTP access and permission to crawl official LaLiga/RFEF pages, then merge against the master teams/grounds files.
